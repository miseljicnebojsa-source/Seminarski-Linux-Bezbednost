#include <iostream>
#include <fstream>
#include <string>

using namespace std;

struct Dozvola {
    string nazivFajla;
    int vrednost;
    Dozvola* sledeci;
};

void dodajNaKraj(Dozvola*& glava, string naziv, int dozvola)
{
    Dozvola* novi = new Dozvola;

    novi->nazivFajla = naziv;
    novi->vrednost = dozvola;
    novi->sledeci = nullptr;

    if(glava == nullptr)
    {
        glava = novi;
    }
    else
    {
        Dozvola* temp = glava;

        while(temp->sledeci != nullptr)
        {
            temp = temp->sledeci;
        }

        temp->sledeci = novi;
    }
}

string analizaDozvole(int dozvola)
{
    if(dozvola == 600 || dozvola == 640 || dozvola == 700)
    {
        return "Visok nivo bezbednosti";
    }
    else if(dozvola == 755)
    {
        return "Umereno bezbedno";
    }
    else if(dozvola == 777)
    {
        return "Nebezbedno";
    }
    else
    {
        return "Nepoznata vrednost";
    }
}

int main()
{
    Dozvola* lista = nullptr;

    ifstream ulaz("dozvole.txt");

    string naziv;
    int dozvola;

    while(ulaz >> naziv >> dozvola)
    {
        dodajNaKraj(lista, naziv, dozvola);
    }

    ulaz.close();

    ofstream izlaz("izvestaj.txt");

    Dozvola* temp = lista;

    while(temp != nullptr)
    {
        izlaz << temp->nazivFajla
              << " -> "
              << analizaDozvole(temp->vrednost)
              << endl;

        temp = temp->sledeci;
    }

    izlaz.close();

    cout << "Analiza zavrsena." << endl;
    cout << "Rezultati su upisani u datoteku izvestaj.txt" << endl;

    return 0;
}
