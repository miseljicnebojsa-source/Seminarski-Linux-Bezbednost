#include <iostream>
#include <fstream>
#include <string>

using namespace std;

struct Dozvola
{
    string nazivFajla;
    int vrednost;
    Dozvola* sledeci;
};

void dodajNaKraj(Dozvola*& glava, string naziv, int dozvola)
{
    Dozvola* novi = new Dozvola;

    novi->nazivFajla = naziv;
    novi->vrednost = dozvola;
    novi->sledeci = nullptr;

    if (glava == nullptr)
    {
        glava = novi;
    }
    else
    {
        Dozvola* trenutni = glava;

        while (trenutni->sledeci != nullptr)
        {
            trenutni = trenutni->sledeci;
        }

        trenutni->sledeci = novi;
    }
}

string analizaDozvole(int dozvola)
{
    if (dozvola == 600 || dozvola == 640 || dozvola == 700)
    {
        return "Visok nivo bezbednosti";
    }
    else if (dozvola == 755)
    {
        return "Umereno bezbedno";
    }
    else if (dozvola == 777)
    {
        return "Nebezbedno";
    }
    else
    {
        return "Nepoznata vrednost";
    }
}

int main()
{
    Dozvola* lista = nullptr;

    ifstream ulaz("dozvole.txt");

    string naziv;
    int dozvola;

    while (ulaz >> naziv >> dozvola)
    {
        dodajNaKraj(lista, naziv, dozvola);
    }

    ulaz.close();

    cout << "Prikaz liste:" << endl;

    Dozvola* trenutni = lista;

    while (trenutni != nullptr)
    {
        cout << trenutni->nazivFajla
             << " -> "
             << analizaDozvole(trenutni->vrednost)
             << endl;

        trenutni = trenutni->sledeci;
    }

    ofstream izlaz("izvestaj.txt");

    trenutni = lista;

    while (trenutni != nullptr)
    {
        izlaz << trenutni->nazivFajla
              << " -> "
              << analizaDozvole(trenutni->vrednost)
              << endl;

        trenutni = trenutni->sledeci;
    }

    izlaz.close();

    cout << endl;
    cout << "Analiza zavrsena." << endl;
    cout << "Rezultati su upisani u datoteku izvestaj.txt" << endl;

    while (lista != nullptr)
    {
        Dozvola* zaBrisanje = lista;
        lista = lista->sledeci;
        delete zaBrisanje;
    }

    return 0;
}
